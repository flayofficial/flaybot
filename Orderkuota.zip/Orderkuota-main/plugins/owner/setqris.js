const { uploadByBuffer } = require('telegraph-uploader');
const fs = require('fs').promises;

exports.run = {
   usage: ['setqris'],
   category: 'owner',
   async: async (m, { client, Func, Scraper, setting }) => {
      try {
         let q = m.quoted || m;
         let mime = (q.msg || q).mimetype || '';

         if (!mime.includes('image')) {
            return client.reply(m.chat, Func.texted('bold', '🚩 Please reply to an image.'), m);
         }

         client.sendReact(m.chat, '🕒', m.key);
         let mediaBuffer = await q.download();

         const fileExtension = mime.includes('image') ? 'png' : 'mp4';
         const fileName = `./media/${Date.now()}.${fileExtension}`;

         // Save the file to the directory
         await fs.writeFile(fileName, mediaBuffer);

         const contentType = mime.includes('image') ? 'image/png' : 'video/mp4';
         const response = await uploadByBuffer(await fs.readFile(fileName), contentType);

         // Delete the file after the process is completed
         await fs.unlink(fileName);
         
         setting.qris = response.link

         client.reply(m.chat, Func.texted('bold', `🚩 Qris berhasil di ganti.`), m)
         client.sendReact(m.chat, '✅', m.key)
      } catch (e) {
         console.error(e);
         client.reply(m.chat, global.status.error, m);
      }
   },
   error: false,
   owner: true,
   cache: true,
   location: __filename
};
