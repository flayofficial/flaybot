exports.run = {
   usage: ['setstatus'],
   use: 'text', 
   category: 'owner',
   async: async (m, {
      client,
      Func, 
      text, 
      command, 
      isPrefix
   }) => {
      try {
         // Your Code
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'WhatsApp Bot Simple By YanaMiku'), m);
         if (text.length > 139) return client.reply(m.chat, '🚩 Max name 25 Character', m);
         await client.updateProfileStatus(text);
         client.reply(m.chat, '*✅ Berhasil mengganti status Bot*', m);
      } catch (e) {
         return console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   owner: true, 
   location: __filename
}