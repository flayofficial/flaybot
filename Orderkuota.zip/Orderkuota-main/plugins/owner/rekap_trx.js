const moment = require('moment-timezone');
const fetch = require('node-fetch');

exports.run = {
  usage: ['rekap-trx'],
  use: 'harian|bulanan|tahunan', 
  category: 'owner', 
  async: async (m, { client, text }) => {
    try {
      if (!text) return client.reply(m.chat, 'Silakan tentukan opsi rekap: harian, bulanan, atau tahunan.', m);
      
      const option = text.toLowerCase().trim();
      let result = '';

      // Ambil konten file transaksi.json
      const user = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${user}/ord-signup/contents/transaksi.json`; // Perbaikan kutipan di sini
      const token = process.env.TOKEN_GH;
      const response = await fetch(apiUrl, { headers: { Authorization: `Bearer ${token}` } });
      const data = await response.json();
      const decodedContent = Buffer.from(data.content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Buat array untuk menyimpan transaksi yang sesuai dengan opsi rekap
      const transactions = [];
      const now = moment();

      for (const key in jsonData.data) {
        const transaction = jsonData.data[key];
        const transactionDate = moment(transaction.tanggal, 'YYYY-MM-DD HH:mm');

        // Sesuaikan dengan opsi rekap
        switch (option) {
          case 'harian':
            if (now.isSame(transactionDate, 'day')) {
              transactions.push(transaction);
            }
            break;
          case 'bulanan':
            if (now.isSame(transactionDate, 'month')) {
              transactions.push(transaction);
            }
            break;
          case 'tahunan':
            if (now.isSame(transactionDate, 'year')) {
              transactions.push(transaction);
            }
            break;
          default:
            return client.reply(m.chat, 'Opsi rekap tidak valid. Silakan gunakan: harian, bulanan, atau tahunan.', m);
        }
      }

      // Jika tidak ada transaksi yang sesuai
      if (transactions.length === 0) {
        return client.reply(m.chat, 'Tidak ada transaksi yang sesuai dengan opsi rekap.', m);
      }

      // Membuat hasil rekap
      result += `*❒  R E K A P - T R X* \n`;
      result += `Opsi Rekap: ${option.charAt(0).toUpperCase() + option.slice(1)}\n`;
      result += `Waktu Sekarang: ${now.format('YYYY-MM-DD HH:mm:ss')}\n\n`;

      transactions.forEach((transaction, index) => {
        result += `Transaction ${index + 1}:\n`;
        result += `Status: ${transaction.status}\n`;
        result += `Tanggal: ${transaction.tanggal}\n`;
        result += `Harga: ${transaction.harga}\n`;
        result += `Refund: ${transaction.refund ? 'True' : 'False'}\n\n`;
      });

      client.reply(m.chat, result + `${global.footer}`, m);
    } catch (e) {
      console.error(e);
      client.reply(m.chat, `Error: ${e}`, m);
    }
  },
  error: false,
  owner: true, 
  location: __filename,
};
