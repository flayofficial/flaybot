exports.run = {
   usage: ['batal'],
   async: async (m, {
      client,
      Func, 
      users
   }) => {
      try {
         if (users.orderkuota_deposit === false) return
        users.orderkuota_deposit = false;
        users.orderkuota_deposit_amount = 0;
        users.depo_masuk = 0;
        users.orderkuota_id = '';
        users.deposit_options = false;
        await client.reply(m.chat, '🚩 *Aktivasi pembayaran berhasil dihapus*', m); 
      } catch (e) {
         return console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   location: __filename
}