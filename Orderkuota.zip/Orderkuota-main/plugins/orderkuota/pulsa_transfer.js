const fetch = require('node-fetch');
const idHarga = process.env.ORDERKUOTA_HARGA_ID;
const apiUrl = `https://okeconnect.com/harga/json?id=${idHarga}&produk=pulsa_transfer`;

async function fetchPulsaList(operator, page) {
  try {
    const response = await fetch(apiUrl);
    const result = await response.json();

    if (operator) {
      const filteredList = result.filter(product => product.produk.toLowerCase() === operator.toLowerCase());
      const startIndex = (page - 1) * 5;
      const endIndex = startIndex + 5;
      return { filteredList: filteredList.slice(startIndex, endIndex), endIndex, total: filteredList.length }; // Menambahkan total jumlah produk
    }

    const startIndex = (page - 1) * 5;
    const endIndex = startIndex + 5;
    return { result: result.slice(startIndex, endIndex), endIndex, total: result.length }; // Menambahkan total jumlah produk
  } catch (error) {
    console.error('Error fetching pulsa list:', error);
    throw 'Terjadi kesalahan saat mengambil daftar pulsa.';
  }
}

exports.run = {
  usage: ['pulsatf'],
  async: async (m, { client, text, Func }) => {
    try {
      if (!text) return;
      const parts = text.split('|');
      const operator = parts[0].toLowerCase();
      let page = parts[1] ? parseInt(parts[1]) : 1;
      if (isNaN(page)) return client.reply(m.chat, '🚩 *Page harus berupa nomor*', m);
      const { filteredList, result, endIndex, total } = await fetchPulsaList(operator, page); // Menangkap total jumlah produk

      if (!filteredList && !result) {
        throw `❌ Tidak ada daftar pulsa untuk operator '${operator}'.`;
      }

      const maxPage = Math.ceil(total / 5); // Menghitung total halaman

      if (page > maxPage) {
        throw `❌ Tidak ada daftar produk dalam halaman ${page}.`;
      }

let laba = parseInt(process.env.ORDERKUOTA_LABA);

      const formattedList = (filteredList ? filteredList : result).map(product => (
        `🆔 *Kode*: ${product.kode}\n` +
        `📝 *Keterangan*: ${product.keterangan}\n` +
        `📱 *Operator*: ${product.produk}\n` +
        `💵 *Harga*: Rp ${Func.formatNumber(parseInt(product.harga) + parseInt(laba))}\n` +
        `🟢 *Status*: ${product.status === '1' ? 'Aktif' : 'Nonaktif'}\n` +
        `__________________________\n`
      ));

      let message = '';
      if (total > endIndex) { // Menambahkan pesan jika masih terdapat produk yang tersedia
        message += `\nKirim *\`pulsatf ${operator}|${page + 1}\`* untuk melanjutkan ke halaman berikutnya\n`;
      }

      client.reply(m.chat, `🔴 *DAFTAR PULSA TRANSFER ${operator.toUpperCase()} (Page ${page}/${maxPage})*\n\n${formattedList.join('\n')}${message}\n\n${global.footer}`, m);
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};
