const fetch = require('node-fetch');

exports.run = {
   usage: ['search'],
   use: 'query', 
   category: 'orderkuota',
   async: async (m, { client, text, isPrefix, command, Func }) => {
      try {
         if (!text) {
            return client.reply(m.chat, Func.example(isPrefix, command, 'indosat'), m);
         }

         const response = await searchProduct(text);

         if (!response || !response.length) {
            return client.reply(m.chat, 'Tidak ada hasil yang ditemukan.', m);
         }

         let resultText = `*🔍  S E A R C H*\n\n❓Query : ${text}\n🛍️Result : ${response.length}\n\n*____________________________*\n\n`;

         for (const product of response) {
            resultText += `🆔Kode Produk : ${product.kode}\n`;
            resultText += `📝Keterangan : ${product.keterangan}\n`;
            resultText += `🛒Produk : ${product.produk}\n`;
        let hrga = parseInt(product.harga);
        let laba = parseInt(process.env.ORDERKUOTA_LABA);
        let total = hrga + laba;
            resultText += `🏷️Kategori : ${product.kategori}\n`;
            resultText += `💵Harga : ${total}\n`;
            resultText += `🟢Status : ${product.status === '1' ? 'Aktif ✅' : 'Nonaktif ❎'}\n`;
            resultText += '*____________________________*\n\n';
         }

         client.reply(m.chat, resultText + `${global.footer}`, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, 'Terjadi kesalahan dalam pencarian.', m);
      }
   },
   error: false,
   owner: false,
   location: __filename
};

// Fungsi untuk mencari produk berdasarkan query
async function searchProduct(query) {
   try {
const idHarga = process.env.ORDERKUOTA_HARGA_ID;
      const apiUrl = `https://okeconnect.com/harga/json?id=${idHarga}`;

      const response = await fetch(apiUrl);
      const data = await response.json();

      // Filter produk berdasarkan query
      const filteredProducts = data.filter(product => product.keterangan.toLowerCase().includes(query.toLowerCase()));

      return filteredProducts;
   } catch (error) {
      console.error('Failed to search for product:', error.message);
      throw error;
   }
}