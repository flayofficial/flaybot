const fetch = require('node-fetch');
const crypto = require('crypto');

// Fungsi untuk membuat signature
function generateSignature(memberID, product, dest, refID, pin, password) {
  const textToHash = `OtomaX${memberID}${product}${dest}${refID}${pin}${password}`;
  const hashedText = crypto.createHash('sha1').update(textToHash).digest('base64');
  return hashedText;
}

exports.run = {
  usage: ['cek-status-trx'],
  use: 'produk|tujuan|refID', 
  category: 'orderkuota', 
  async: async (m, { client, text, isPrefix, command }) => {
    try {
      if (!text) return client.reply(m.chat, `Silakan masukkan kode produk, nomor tujuan, dan refID dalam format yang benar.

• Example :
${isPrefix + command} code_produk|nomor_tujuan|refID`, m);

      const [product, dest, refID] = text.split('|');

      if (!product || !dest || !refID) {
        return client.reply(m.chat, `Format yang Anda masukkan salah. Silakan gunakan format yang benar, contoh: ${isPrefix + command} S5|082280004280|1234`, m);
      }
      
      // Mengecek apakah transaksi sudah ada dalam transaksi.json
      const transactionExists = await checkTransactionExists(product, dest, refID, m);
      
      // Jika transaksi tidak ada, kirim pesan
      if (!transactionExists) return client.reply(m.chat, 'Transaksi tersebut tidak ada.', m);
      
      // Jika transaksi ada, lakukan pembelian
      const memberID = process.env.ORDERKUOTA_ID;
      const pin = process.env.ORDERKUOTA_PIN;
      const password = process.env.ORDERKUOTA_PASSWORD;

      const signature = generateSignature(memberID, product, dest, refID, pin, password);

      const url = `https://h2h.okeconnect.com/trx?memberID=${memberID}&pin=${pin}&password=${password}&product=${product}&dest=${dest}&refID=${refID}&sign=${signature}`;

      const response = await fetch(url);
      const result = await response.text();
      
      client.reply(m.chat, result, m); 
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};

async function checkTransactionExists(product, dest, refID, m) {
  try {
    const gh = process.env.USERNAME_GH;
    const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/transaksi.json`;
    const token = process.env.TOKEN_GH;

    // Dapatkan konten file transaksi.json
    const response = await fetch(apiUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    const data = await response.json();

    const decodedContent = Buffer.from(data.content, 'base64').toString('utf-8');
    const jsonData = JSON.parse(decodedContent);

    // Mengecek apakah transaksi sudah ada
    const transactionKey = `${product}°${dest}°${refID}°${(m.sender).split('@')[0]}`;
    return jsonData.data.hasOwnProperty(transactionKey);
  } catch (error) {
    console.error('Failed to check transaction existence:', error.message);
    throw error;
  }
}
