const fetch = require('node-fetch');
const moment = require('moment-timezone');

exports.run = {
   usage: ['deposit'],
   use: 'jumlah', 
   category: 'orderkuota',
   async: async (m, {
      client,
      Func, 
      args, 
      users, 
      setting,
      command, 
      isPrefix
   }) => {
      try {
         if (users.orderkuota_deposit === true) return client.reply(m.chat, '🚩 *Kamu memiliki aktivasi pembayaran yang belum terselesaikan. Lakukan pembayaran terlebih dahulu atau kirim "batal" untuk membatalkan aktivasi pembayaran.*', m);
         let depo = parseInt(args[0]);
         if (depo < 1000) return client.reply(m.chat, '🚩 *Minimal deposit adalah Rp. 1,000*', m);
         if (isNaN(depo)) return client.reply(m.chat, `• Example :
${isPrefix + command} 7000`, m);
         let randomId = Func.randomInt(111111, 999999);
        users.orderkuota_deposit = true;
        users.orderkuota_id = randomId;

        const fee = 0.3; // fee admin 0.3% 
        const tambahan = depo * (fee / 100);
        users.depo_masuk += depo - tambahan;
        users.orderkuota_deposit_amount += depo; 
         users.deposit_options = true;
         if (users.deposit_options === true) return client.reply(m.chat, `*❒  D E P O - O P T I O N S*
         
1 - Qris (otomatis deposit)
2 - Transfer Via Nomor (manual confirm)

Kirim pesan *1* / *2*, sesuai dengan pilihan anda`, m)
      } catch (e) {
         return console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   location: __filename
}