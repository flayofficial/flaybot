const fetch = require('node-fetch');

const idHarga = process.env.ORDERKUOTA_HARGA_ID;
const apiUrl = `https://okeconnect.com/harga/json?id=${idHarga}&produk=finance`;

async function fetchGameList() {
  try {
    const response = await fetch(apiUrl);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error fetching product list:', error);
    throw 'Terjadi kesalahan saat mengambil daftar produk.';
  }
}

exports.run = {
  usage: ['fnce'],
  async: async (m, { client, text, args, Func, command, isPrefix }) => {
    try {
      if (!args[0]) return;
      if (!text.includes('|') && isNaN(text)) return;

      const gameList = await fetchGameList();

      let page = 1;
      let index = 0;

      if (text.includes('|')) {
        const [num, pg] = text.split('|');
        index = parseInt(num) - 1;
        page = parseInt(pg);
        if (isNaN(page)) return client.reply(m.chat, `🚩 *Page harus berupa nomor*

• Example : ${isPrefix + command} ${num}|2`, m);
      } else {
        index = parseInt(text) - 1;
      }

      const pageSize = 5;
      const startIndex = (page - 1) * pageSize;
      const endIndex = startIndex + pageSize;

      const uniqueOptions = Array.from(new Set(gameList.map(option => option.produk)));
      const totalOptions = uniqueOptions.length;

      if (index < 0 || index >= totalOptions) {
        throw 'Nomor produk tidak valid.';
      }

      const selectedProduct = uniqueOptions[index];

      // Filter produk berdasarkan produk yang dipilih
      const filteredList = gameList.filter(product => product.produk === selectedProduct && parseInt(product.harga) >= 0);

      // Urutkan produk berdasarkan harga terendah
      filteredList.sort((a, b) => parseInt(a.harga) - parseInt(b.harga));

      const totalProducts = filteredList.length;
      const maxPage = Math.ceil(totalProducts / pageSize);

      if (totalProducts === 0) {
        if (page > maxPage) {
          throw `Tidak ada produk ${selectedProduct} dalam halaman ${page}.`;
        } else {
          throw `Tidak ada produk ${selectedProduct} dalam halaman tersebut.`;
        }
      }

      const options = filteredList.slice(startIndex, endIndex);

      let message = `🛍️  *${selectedProduct.toUpperCase()}*\n\n`;

      message += `Terdapat ${totalProducts} produk pada produk : ${selectedProduct}\n`;
      message += `\n> *Page : ${page}/${maxPage}*\n\n`;

      options.forEach((product, i) => {
        message += `*${startIndex + i + 1}.*\n`;
        message += `• *Kode*: ${product.kode}\n`;
        message += `• *Keterangan*: ${product.keterangan}\n`;
        let hrga = parseInt(product.harga);
        let laba = parseInt(process.env.ORDERKUOTA_LABA);
        let total = hrga + laba;
        message += `• *Kategori*: ${product.kategori}\n`;
        message += `• *Harga*: Rp ${total}\n`;
        message += `• *Status*: ${product.status === '1' ? 'Aktif ✅' : 'Nonaktif ❎'}\n`;
        message += `*____________________________*\n\n`;
      });

      // Cek apakah ada produk lagi di page selanjutnya
      const nextPageStartIndex = endIndex;
      const nextPageEndIndex = nextPageStartIndex + pageSize;
      const hasNextPage = nextPageStartIndex < totalProducts;

      if (hasNextPage) {
        message += `Kirim *\`${command} ${index + 1}|${page + 1}\`* untuk pergi ke halaman ${page + 1}\n\n`;
      }

      client.reply(m.chat, message + `${global.footer}`, m);
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};
