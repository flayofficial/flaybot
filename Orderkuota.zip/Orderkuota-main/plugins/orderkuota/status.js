const fetch = require('node-fetch');
const idHarga = process.env.ORDERKUOTA_HARGA_ID;
const apiUrl = `https://okeconnect.com/harga/json?id=${idHarga}`;

async function fetchProductList() {
  try {
    const response = await fetch(apiUrl);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error fetching product list:', error);
    throw 'Terjadi kesalahan saat mengambil daftar produk.';
  }
}

exports.run = {
  usage: ['status'],
  category: 'orderkuota',
  async: async (m, { client, Func }) => {
    try {
      const productList = await fetchProductList();

      const activeProducts = productList.filter(product => product.status === "1").length;
      const inactiveProducts = productList.length - activeProducts;

      const message = `🟢 *S T A T U S*\n\n`
                    + `✅ Produk Aktif : ${Func.formatNumber(activeProducts)}\n`
                    + `❎ Produk Tidak Aktif : ${Func.formatNumber(inactiveProducts)}`;

      client.reply(m.chat, message, m);
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};