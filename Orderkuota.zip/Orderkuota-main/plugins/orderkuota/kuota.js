const fetch = require('node-fetch');
const idHarga = process.env.ORDERKUOTA_HARGA_ID;
const apiUrl = {
  smartfren: `https://okeconnect.com/harga/json?id=${idHarga}&produk=kuota_smartfren`,
  axis: `https://okeconnect.com/harga/json?id=${idHarga}&produk=kuota_axis`,
  xl: `https://okeconnect.com/harga/json?id=${idHarga}&produk=kuota_xl`,
  indosat: `https://okeconnect.com/harga/json?id=${idHarga}&produk=kuota_indosat`,
  telkomsel: `https://okeconnect.com/harga/json?id=${idHarga}&produk=kuota_telkomsel`,
  tri: `https://okeconnect.com/harga/json?id=${idHarga}&produk=kuota_tri`,
  byu: `https://okeconnect.com/harga/json?id=${idHarga}&produk=kuota_byu`,
};

async function fetchKuotaList(produk) {
  try {
    const response = await fetch(apiUrl[produk]);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error(`Error fetching ${produk} kuota list:`, error);
    throw `Terjadi kesalahan saat mengambil daftar ${produk} kuota.`;
  }
}

exports.run = {
  usage: ['kuota'],
  async: async (m, { client, args, Func, command }) => {
    try {
      if (!args[0]) return
      const produk = args[0]
      if (!apiUrl.hasOwnProperty(produk)) return client.reply(m.chat, `🚩 Produk kuota tidak valid.
 
- indosat
- axis
- smartfren
- xl
- telkomsel
- tri
- byu

• Example :
${command} kuota indosat`, m);

      const kuotaList = await fetchKuotaList(produk);

      const page = args[1] ? parseInt(args[1]) : 1;
      if (isNaN(page)) return client.reply(m.chat, '🚩 *Page harus berupa nomor*', m);
      const pageSize = 10;
      const startIndex = (page - 1) * pageSize;
      const endIndex = startIndex + pageSize;

      const options = kuotaList.slice(startIndex, endIndex);

      if (options.length === 0) throw `Tidak ada daftar kuota ${produk} untuk halaman tersebut.`;

      let message = `🌐  *K U O T A - ${produk.toUpperCase().split('').join(' ')}*\n\n`;

      options.forEach((option, index) => {
        message += `*# Kode : ${option.kode}*\n`;
        message += `○ ${option.keterangan}\n`;
        message += `○ ${option.produk}\n`;
        let hrga = parseInt(option.harga);
        let laba = parseInt(process.env.ORDERKUOTA_LABA);
        let total = hrga + laba;
        message += `*Harga*: Rp ${Func.formatNumber(total)}\n`;
        message += `*Status*: ${option.status === '1' ? 'Aktif ✅' : 'Nonaktif ❎'}\n`;
        message += `*_________________________*\n\n`; 
      });

      const maxPage = Math.ceil(kuotaList.length / pageSize);
      message += `Halaman : *${page}/${maxPage}*\n`;

      if (kuotaList.length > endIndex) {
        message += `\nKirim *\`${command} ${produk} ${page + 1}\`* untuk melanjutkan ke halaman selanjutnya\n`;
      }

      client.reply(m.chat, message + '\n' + `${global.footer}`, m);
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};
