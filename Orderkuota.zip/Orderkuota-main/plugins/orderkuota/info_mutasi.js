const fetch = require('node-fetch');

exports.run = {
   usage: ['info-mutasi'],
   category: 'orderkuota',
   async: async (m, { client, Func }) => {
      try {
         const id = process.env.ORDERKUOTA_ID;
         const apikey = process.env.ORDERKUOTA_APIKEY;
         const apiUrl = `https://gateway.okeconnect.com/api/mutasi/qris/${id}/${apikey}`;

         const requestOptions = {
            method: 'GET',
            redirect: 'follow'
         };

         const response = await fetch(apiUrl, requestOptions);
         const result = await response.json();

         if (result.status !== 'success') {
            throw 'Terjadi kesalahan saat mengambil data.';
         }

         const data = result.data;
         let message = '🔴 ORDERKUOTA DEPO MUTASI\n\n';

         if (data.length === 0) {
            message += 'Tidak ada data mutasi.';
         } else {
            data.forEach(entry => {
               message += `Date: ${entry.date}\nAmount: ${entry.amount}\nType: ${entry.type}\nQRIS: ${entry.qris}\nBrand Name: ${entry.brand_name}\nIssuer Reff: ${entry.issuer_reff}\nBuyer Reff: ${entry.buyer_reff}\nBalance: ${entry.balance}\n\n`;
            });
         }

         await client.reply(m.chat, message, m);
      } catch (e) {
         console.error(e);
         await client.reply(m.chat, `🚩 ${e}`, m);
      }
   },
   error: false,
   owner: true, 
   location: __filename
};

