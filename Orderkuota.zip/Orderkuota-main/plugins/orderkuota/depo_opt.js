const fetch = require('node-fetch');
const moment = require('moment-timezone');

exports.run = {
   async: async (m, {
      client,
      Func, 
      users, 
      setting 
   }) => {
      try {
         if (users.deposit_options === true) {
            let opt = m.text.trim();
            if (opt === '1') {
         client.sendReact(m.chat, '🕘', m.key)
         const qris = setting.qris;
        client.sendFile(m.chat, qris, 'image.jpg', `*❒ AKTIVASI DEPOSIT*
        
○ Jumlah Pengisian : Rp. ${Func.formatNumber(users.orderkuota_deposit_amount)}
○ Total Pembayaran : Rp. ${Func.formatNumber(users.orderkuota_deposit_amount)}
○ Status : Proses 🕘
○ Id Transaksi : ${users.orderkuota_id}

*Catatan :*
- Lakukan Pembayaran Sebelum : ${moment().add(12, 'hours').format('DD-MM-YYYY HH:mm')}
- Setelah melakukan pembayaran, tunggu beberapa saat, kemudian kirim *check* untuk menampilkan status pembayaran.
- Jika ingin membatalkan pengisian deposit, kirim *batal*.
- Jika status berhasil, deposit Anda akan otomatis bertambah sebesar Rp. ${Func.formatNumber(users.depo_masuk)}. - 0,3%
- Apabila ada kendala lain, silahkan hubungi *owner*`, m);
client.sendReact(m.chat, '🛍️', m.key)
users.deposit_options = false;
            }
            if (opt === '2') {
            client.sendReact(m.chat, '🕘', m.key)
               client.reply(m.chat, setting.payment + `\n${global.footer}

Setelah selesai transfer. Kirim perintah *bukti + gambar screenshot transfer*`, m)
users.deposit_options = false;
client.sendReact(m.chat, '🛍️', m.key)
            }
         } 
      } catch (e) {
         return console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   location: __filename
}
