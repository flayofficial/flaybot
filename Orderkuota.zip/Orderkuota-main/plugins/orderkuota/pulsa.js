const fetch = require('node-fetch');
const idHarga = process.env.ORDERKUOTA_HARGA_ID;
const apiUrl = {
  pulsa: `https://okeconnect.com/harga/json?id=${idHarga}&produk=pulsa`,
  transfer: `https://okeconnect.com/harga/json?id=${idHarga}&produk=pulsa_transfer`,
};

async function fetchData(produk) {
  try {
    const response = await fetch(apiUrl[produk]);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error(`Error fetching ${produk} list:`, error);
    throw `Terjadi kesalahan saat mengambil daftar ${produk}.`;
  }
}

exports.run = {
  usage: ['pulsa'],
  async: async (m, { client, args, Func, command, isPrefix }) => {
    try {
      if (!args[0]) {
        const pulsaList = await fetchData('pulsa');
        const transferList = await fetchData('transfer');

        const uniqueOptionsPulsa = Array.from(new Set(pulsaList.map(option => option.produk)));
        const uniqueOptionsTransfer = Array.from(new Set(transferList.map(option => option.produk)));

        const formattedListPulsa = uniqueOptionsPulsa.map((product, index) => (
          `~ ${product}`
        ));

        const formattedListTransfer = uniqueOptionsTransfer.map((product, index) => (
          `~ ${product}`
        ));

        let message = `📱  *P U L S A*\n\n`;
        message += formattedListPulsa.join('\n');
        message += `\n\n• Example :\n${isPrefix + command} Axis\n\n🔄. *P U L S A - T F*\n\n`;
        message += formattedListTransfer.join('\n');

        return client.reply(m.chat, message + `\n\n• Example :\n${isPrefix}pulsatf telkomsel transfer` + '\n\n' + `${global.footer}`, m);
      } else {
        let text = args.join(' ').toLowerCase(); // Menggabungkan argumen menjadi satu string
        let page = 1; // Menetapkan page default
        
        // Memeriksa apakah ada nomor halaman yang disertakan
        if (text.includes(' ~ ')) {
          [text, page] = text.split(' ~ ');
          page = parseInt(page); // Mengonversi nomor halaman ke tipe data yang sesuai
        }
        if (isNaN(page)) return client.reply(m.chat, '🚩 *Page harus berupa nomor*', m);
        
        const produk = text;
        
        if (produk === 'transfer') {
          const transferList = await fetchData('transfer');

          const pageSize = 20;
          const startIndex = (page - 1) * pageSize;
          const endIndex = startIndex + pageSize;

          const uniqueOptions = Array.from(new Set(transferList.map(option => option.produk)));

          const options = uniqueOptions.slice(startIndex, endIndex);

          if (options.length === 0) throw `Tidak ada daftar pulsa transfer untuk halaman tersebut.`;

          let message = `🔄  *P U L S A - T F*\n\n`;

          options.forEach((option, index) => {
            message += `~ ${option}\n`;
          });

          const maxPage = Math.ceil(uniqueOptions.length / pageSize); // Menghitung total halaman
          if (page < maxPage) {
            message += `\nKirim *${command} ${produk} ~ ${parseInt(page) + 1}* untuk melanjutkan ke page selanjutnya\n`;
          }

          client.reply(m.chat, message + '\nUntuk melihat daftar layanan produk kirim *\`pulsatf <produk>\`*\n• Example : \`pulsatf telkomsel transfer\`' + '\n\n' + `${global.footer}`, m);
        } else {
          const pulsaList = await fetchData('pulsa');

          const filteredList = pulsaList.filter(product => product.produk.toLowerCase() === produk.toLowerCase());

          if (filteredList.length === 0) {
            throw `❌ Tidak ada daftar pulsa untuk operator '${produk}'.`;
          }

          const startIndex = (page - 1) * 5;
          const endIndex = startIndex + 5;
          const slicedList = filteredList.slice(startIndex, endIndex);

        let laba = parseInt(process.env.ORDERKUOTA_LABA);
          const formattedList = slicedList.map(product => (
            `🆔 *Kode*: ${product.kode}\n` +
            `📝 *Keterangan*: ${product.keterangan}\n` +
            `📱 *Operator*: ${product.produk}\n` +
            `💵 *Harga*: Rp ${Func.formatNumber(parseInt(product.harga) + laba)}\n` +
            `🟢 *Status*: ${product.status === '1' ? 'Aktif ✅' : 'Nonaktif ❎'}\n` +
            `_______________________\n`
          ));

          const maxPage = Math.ceil(filteredList.length / 5); // Menghitung total halaman
          if (page > maxPage) {
            throw `Tidak ada daftar produk dalam page tersebut`;
          }

          let message = `🔴 *DAFTAR PULSA ${produk.toUpperCase()} ~ Page ${page}/${maxPage}*\n\n${formattedList.join('\n')}`;
          if (page < maxPage) {
            message += `\nKirim *\`${command} ${produk} ~ ${parseInt(page) + 1}\`* untuk melanjutkan ke page selanjutnya\n`; }
            return client.reply(m.chat, message + `\n${global.footer}`, m);
    }
  }
} catch (e) {
  return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};
