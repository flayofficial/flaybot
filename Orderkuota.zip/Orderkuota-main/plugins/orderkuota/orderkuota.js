const fetch = require('node-fetch');
const idHarga = process.env.ORDERKUOTA_HARGA_ID;
const apiUrl = `https://okeconnect.com/harga/json?id=${idHarga}`;

async function fetchPulsaList() {
  try {
    const response = await fetch(apiUrl);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error fetching pulsa list:', error);
    throw 'Terjadi kesalahan saat mengambil daftar pulsa.';
  }
}

exports.run = {
  usage: ['orderkuota'],
  category: 'orderkuota',
  async: async (m, { client, args, isPrefix, command }) => {
    try {
      const pulsaList = await fetchPulsaList();

      const page = args[0] ? parseInt(args[0]) : 1;
      if (isNaN(page)) return client.reply(m.chat, '🚩 *Page harus berupa nomor*', m);
      const pageSize = 11;
      const startIndex = (page - 1) * pageSize;
      const endIndex = startIndex + pageSize;

      const uniqueOptions = Array.from(new Set(pulsaList.map(option => option.kategori)));

      const options = uniqueOptions.slice(startIndex, endIndex);

      if (options.length === 0) throw 'Tidak ada daftar produk untuk halaman tersebut.';

      let message = `❒ *O R D E R K U O T A*\n\nUntuk melihat daftar produk\n• Example : ${isPrefix}kuota smartfren\n\n`;

      options.forEach((option, index) => {
        message += `${startIndex + index + 1}. ${option}\n`;
      });

      if (uniqueOptions.length > endIndex) {
        message += `\nKirim *\`${command} ${page + 1}\`* untuk melanjutkan ke page selanjutnya\n`;
      }

      client.reply(m.chat, message + '\n' + `${global.footer}`, m);
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};
