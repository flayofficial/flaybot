const moment = require('moment-timezone');
const axios = require('axios');

exports.run = {
   usage: ['check'],
   use: 'HH:mm|id_transaksi', 
   async: async (m, { client, Func, command, users, isPrefix, text }) => {
      try {
         if (users.orderkuota_deposit === false) return
         if (!text) {
            return client.reply(m.chat, `🚩 Masukkan waktu (jam dan menit) saat anda transfer ke QRIS. Dalam format HH:mm (Jam:Menit)

• *Example* :
${isPrefix + command} 12:26|123456`, m);
         }
         const amount = Func.jsonFormat(users.orderkuota_deposit_amount);
         const id_trx = Func.jsonFormat(users.orderkuota_id);
         const [time, id_transaksi] = text.split('|');

         if (!time || !id_transaksi) {
            return client.reply(m.chat, '🚩 Format waktu atau ID transaksi tidak valid.', m);
         }

         const id = process.env.ORDERKUOTA_ID;
         const apikey = process.env.ORDERKUOTA_APIKEY;

         const requestOptions = {
            method: 'GET',
            redirect: 'follow'
         };

         const response = await fetch(`https://gateway.okeconnect.com/api/mutasi/qris/${id}/${apikey}`, requestOptions);
         const result = await response.json();

         const ttimee = process.env.TZ;

         const foundData = result.data.find(item => moment(item.date).tz(ttimee).format('HH:mm') === time);

         if (!foundData) {
            return client.reply(m.chat, '❌ Data transaksi tidak ditemukan pada waktu tersebut.', m);
         }

         if (foundData.amount !== amount) {
            return client.reply(m.chat, '❌ Jumlah deposit tidak sesuai dengan data transaksi.', m);
         }

         if (id_transaksi !== id_trx) {
            return client.reply(m.chat, '❌ ID transaksi tidak sesuai dengan yang diaktifkan.', m);
         }

         // Add deposit to the user's account
         users.deposit += users.depo_masuk;
         
         let number = (m.sender).split('@')[0];
         
         const saldo = await getSaldo(number);

         // Update saldo di account.json pada repository GitHub
         await updateSaldo(users.depo_masuk, users.jid.split('@')[0]); // Update saldo based on user's number

         const message = `*❒ Data Transaksi*

*${foundData.date}*
○ Amount : *${Func.formatNumber(foundData.amount)}*
○ Type : *${foundData.type}*
○ QRIS : *${foundData.qris}*
○ Brand Name : *${foundData.brand_name}*
○ Issuer Reff : *${foundData.issuer_reff}*
○ Buyer Reff : *${foundData.buyer_reff}*
○ Balance : *Rp. ${Func.formatNumber(saldo + users.depo_masuk)}*

💰 Deposit sebesar Rp. ${Func.formatNumber(users.depo_masuk)} telah berhasil ditambahkan ke akun Anda.

Kirim perintah *saldo* untuk mengecek saldo kamu

${global.footer}`;

         await client.reply(m.chat, message, m);
         users.orderkuota_deposit = false;
         users.orderkuota_deposit_amount = 0;
         users.depo_masuk = 0;
         users.orderkuota_id = '';
         users.deposit_options = false;
         client.sendReact(m.chat, '✅', m.key);
      } catch (e) {
         console.error(e);
         await client.reply(m.chat, `🚩 Terjadi kesalahan dalam memproses permintaan. ${e}`, m);
      }
   },
   error: false,
   location: __filename
};

async function updateSaldo(amount, userNumber) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoNumber = key.split('°')[2];

            if (userInfoNumber === userNumber) {
               jsonData[key].saldo += amount; // Tambahkan saldo deposit masuk
               break;
            }
         }
      }

      const updatedContent = JSON.stringify(jsonData, null, 2);
      const encodedContent = Buffer.from(updatedContent).toString('base64');

      await axios.put(apiUrl, {
         message: `Update saldo deposit masuk ke account.json untuk user ${userNumber}`,
         content: encodedContent,
         sha: response.data.sha,
      }, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
   } catch (error) {
      console.error('Failed to update saldo deposit:', error.message);
      throw error;
   }
}

async function getSaldo(number) {
   try {
const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Cari saldo berdasarkan nomor
      let saldo = null;
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoNumber = key.split('°')[2]; // Ambil nomor dari key

            if (userInfoNumber === number) {
               saldo = userInfo.saldo;
               break;
            }
         }
      }

      return saldo;
   } catch (error) {
      console.error('Failed to get saldo:', error.message);
      throw error;
   }
}
