const fetch = require('node-fetch');
const moment = require('moment-timezone');

exports.run = {
   usage: ['detail-trx'],
   category: 'orderkuota',
   async: async (m, { client, Func, isPrefix, command, args }) => {
      try {
         let time = args[0];
         if (!time) return client.reply(m.chat, `🚩 Masukkan Jam & menit Transaksi

• Example :
${isPrefix + command} HH:mm
${isPrefix + command} 07:19`, m);

         const id = process.env.ORDERKUOTA_ID;
         const apikey = process.env.ORDERKUOTA_APIKEY;

         const requestOptions = {
            method: 'GET',
            redirect: 'follow'
         };

         const response = await fetch(`https://gateway.okeconnect.com/api/mutasi/qris/${id}/${apikey}`, requestOptions);
         const result = await response.json();

         const foundData = result.data.find(item => moment(item.date).tz('Asia/Jakarta').format('HH:mm') === time);

         if (foundData) {
            const message = `*❒ Data Transaksi Mutasi*

*${foundData.date}*
○ Amount : *${Func.formatNumber(foundData.amount)}*
○ Type : *${foundData.type}*
○ QRIS : *${foundData.qris}*
○ Brand Name : *${foundData.brand_name}*
○ Issuer Reff : *${foundData.issuer_reff}*
○ Buyer Reff : *${foundData.buyer_reff}*
○ Balance : *${Func.formatNumber(foundData.balance)}*`;

            await client.reply(m.chat, message, m);
         } else {
            await client.reply(m.chat, '❌ *Data transaksi tidak ditemukan pada waktu tersebut.*', m);
         }
      } catch (e) {
         console.error(e);
         await client.reply(m.chat, `🚩 ${e}`, m);
      }
   },
   error: false,
   location: __filename
};