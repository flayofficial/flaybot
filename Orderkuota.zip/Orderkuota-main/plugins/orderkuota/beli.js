const fetch = require('node-fetch');
const crypto = require('crypto');
const axios = require('axios');
const moment = require('moment-timezone');

// Fungsi untuk membuat signature
function generateSignature(memberID, product, dest, refID, pin, password) {
  const textToHash = `OtomaX${memberID}${product}${dest}${refID}${pin}${password}`;
  const hashedText = crypto.createHash('sha1').update(textToHash).digest('base64');
  return hashedText;
}

exports.run = {
  usage: ['beli'],
  use: 'code_produk|tujuan',
  category: 'orderkuota', 
  async: async (m, { client, text, Func, isPrefix, command, setting }) => {
    try {
      if (!text) return client.reply(m.chat, `Silakan masukkan kode produk, nomor tujuan, dan refID dalam format yang benar.

• Example :
${isPrefix + command} code_produk|tujuan`, m);

      const [code_product, dest] = text.split('|');

      if (!code_product || !dest) {
        return client.reply(m.chat, `Format yang Anda masukkan salah. Silakan gunakan format yang benar, contoh: ${isPrefix + command} S5|082280004280`, m);
      }
      
      // Cek harga produk berdasarkan code produk yang diberikan
      const productCode = code_product;
      const hargaID = process.env.ORDERKUOTA_HARGA_ID;
      const response = await fetch(`https://okeconnect.com/harga/json?id=${hargaID}`);
         const data = await response.json();

         if (!data || data.length === 0) {
            return client.reply(m.chat, 'Data produk tidak ditemukan.', m);
         }

         const product = data.find(prod => prod.kode === productCode);

         if (!product) {
            return client.reply(m.chat, 'Produk dengan kode tersebut tidak ditemukan.', m);
         }
         
         // mendapatkan saldo pengguna
         const number = (m.sender).split('@')[0];
         const saldo = await getSaldo(number);
         // menghitung harga + laba
         let laba = parseInt(process.env.ORDERKUOTA_LABA);
         let total = parseInt(product.harga) + laba;
         // menghitung selisih
         let selisih = total - saldo;
      if (total > saldo) return client.reply(m.chat, `🚩 Saldo kamu tidak mencukupi, Saldo kamu kurang ${Func.formatNumber(selisih)}`, m)
      
         // Ambil total_refID dari transaksi.json
         let total_refID = await getTotalRefID();
         
         // Tambahkan satu ke total_refID
         total_refID++;
         
         // Buat refID
         const refID = total_refID.toString();

         // Tambahkan transaksi baru ke account.json
         await addTransaction(code_product, dest, refID, number, total);

         client.reply(m.chat, 'Transaksi berhasil ditambahkan.', m);
      
      const memberID = process.env.ORDERKUOTA_ID;
      const pin = process.env.ORDERKUOTA_PIN;
      const password = process.env.ORDERKUOTA_PASSWORD;
      
      const signature = generateSignature(memberID, product, dest, refID, pin, password);

      const url = `https://h2h.okeconnect.com/trx?memberID=${memberID}&pin=${pin}&password=${password}&product=${code_product}&dest=${dest}&refID=${refID}&sign=${signature}`;

const response2 = await fetch(url);
const result = await response2.text();

// Ubah format hasil respons
const [, idTransaksi] = /R#(\d+)/.exec(result) || [];
const [, idTransaksiGlobal] = /T#(\d+)/.exec(result) || [];
const [, keterangan] = /([^,]+)/.exec(result) || [];
const [, jamOrder] = /@(\d+:\d+)/.exec(result) || [];

const processedResult = `*🛍️  P R O S E S*

🆔ID Transaksi : ${idTransaksi}
🌐ID Transaksi Global : ${idTransaksiGlobal}
🕘Jam Order : ${jamOrder}

${keterangan}

Jika ingin Mengecek status transaksi, kirim perintah :
*\`cek-status-trx\`* ${code_product}|${dest}|${refID}

${global.footer}`;
client.reply(m.chat, processedResult, m);
         const user = await findUserByNumber(number);

         if (!user) {
            return client.reply(m.chat, 'Pengguna dengan nomor ini tidak ditemukan.', m);
         }

         // Kurangi saldo pengguna
         user.saldo -= total;
         user.total_pembelian += 1;
         user.total_pengeluaran += total;

         // Simpan perubahan ke dalam account.json
         await updateAccountJson(user, total);

         client.reply(m.chat, `Saldo berhasil dikurangi. Sisa Saldo Anda: Rp. ${Func.formatNumber(user.saldo)}`, m);
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};

// Fungsi untuk mendapatkan banyaknya saldo user
async function getSaldo(number) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response3 = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response3.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Cari saldo berdasarkan nomor
      let saldo = null;
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoNumber = key.split('°')[2]; // Ambil nomor dari key

            if (userInfoNumber === number) {
               saldo = userInfo.saldo;
               break;
            }
         }
      }

      return saldo;
   } catch (error) {
      console.error('Failed to get saldo:', error.message);
      throw error;
   }
}

// Fungsi untuk mencari user berdasarkan nomor
async function findUserByNumber(number) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Cari user berdasarkan nomor
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const [, , userNumber] = key.split('°'); // Ambil nomor dari key

            if (userNumber === number) {
               return {
                  key: key,
                  saldo: userInfo.saldo
               };
            }
         }
      }

      return null; // Pengguna tidak ditemukan
   } catch (error) {
      console.error('Gagal menemukan pengguna berdasarkan nomor:', error.message);
      throw error;
   }
}

// Fungsi untuk memperbarui saldo dalam account.json
async function updateAccountJson(user, total) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      let jsonData = JSON.parse(decodedContent);

      // Update saldo pengguna
      jsonData[user.key].saldo = user.saldo;
      jsonData[user.key].total_pengeluaran += total;
      jsonData[user.key].total_pembelian += 1;

      // Encode dan simpan perubahan pada account.json
      const updatedContent = JSON.stringify(jsonData, null, 2);
      const encodedContent = Buffer.from(updatedContent).toString('base64');

      await axios.put(apiUrl, {
         message: `Update saldo for ${user.key}`,
         content: encodedContent,
         sha: response.data.sha,
      }, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
   } catch (error) {
      console.error('Gagal memperbarui saldo dalam account.json:', error.message);
      throw error;
   }
}

// Fungsi untuk mengambil total_refID dari transaksi.json
async function getTotalRefID() {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/transaksi.json`;
      const token = process.env.TOKEN_GH;

      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
      
      const data = response.data;
      const decodedContent = Buffer.from(data.content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      return jsonData.total_refID;
      return jsonData.total_uang_masuk;
   } catch (error) {
      console.error('Failed to get total_refID:', error.message);
      throw error;
   }
}

// Fungsi untuk menambahkan transaksi baru ke transaksi.json
async function addTransaction(code_product, dest, refID, number, total) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/transaksi.json`;
      const token = process.env.TOKEN_GH;

      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
      
      const data = response.data;
      const decodedContent = Buffer.from(data.content, 'base64').toString('utf-8');
      let jsonData = JSON.parse(decodedContent);

      // Tambahkan transaksi baru
      const transactionKey = `${code_product}°${dest}°${refID}°${number}`;
      jsonData.data[transactionKey] = {
         harga: total,
         status: "PROSES",
         refund: false,
         tanggal: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm")
      };
      
      // Update total_refID
      jsonData.total_refID = parseInt(jsonData.total_refID) + 1;
      // Update total_uang_masuk
      jsonData.total_uang_masuk = parseInt(jsonData.total_uang_masuk) + total;

      // Encode dan simpan perubahan pada transaksi.json
      const updatedContent = JSON.stringify(jsonData, null, 2);
      const encodedContent = Buffer.from(updatedContent).toString('base64');

      await axios.put(apiUrl, {
         message: `Add new transaction ${transactionKey}`,
         content: encodedContent,
         sha: data.sha,
      }, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
   } catch (error) {
      console.error('Failed to add transaction:', error.message);
      throw error;
   }
}