const fetch = require('node-fetch');
const idHarga = process.env.ORDERKUOTA_HARGA_ID;
const apiUrl = `https://okeconnect.com/harga/json?id=${idHarga}&produk=tagihan_pbb`;
const apiUrl2 = `https://okeconnect.com/harga/json?id=${idHarga}&produk=tagihan`;

async function fetchGameList() {
  try {
    const response = await fetch(apiUrl);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error fetching product list:', error);
    throw 'Terjadi kesalahan saat mengambil daftar Produk.';
  }
}

async function fetchGame2List() {
  try {
    const response = await fetch(apiUrl2);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error fetching product list:', error);
    throw 'Terjadi kesalahan saat mengambil daftar Produk.';
  }
}

exports.run = {
  usage: ['tagihan'],
  async: async (m, { client, args, command }) => {
    try {
      if (!args[0]) {
      const gameList = await fetchGame2List();

      const page = args[1] ? parseInt(args[1]) : 1;
      if (isNaN(page)) return client.reply(m.chat, '🚩 *Page harus berupa nomor*', m);
      const pageSize = 2000;
      const startIndex = (page - 1) * pageSize;
      const endIndex = startIndex + pageSize;

      const uniqueOptions = Array.from(new Set(gameList.map(option => option.produk)));

      const options = uniqueOptions.slice(startIndex, endIndex);

      const totalOptions = uniqueOptions.length;
      const totalPages = Math.ceil(totalOptions / pageSize);

      if (options.length === 0) throw 'Tidak ada daftar produk untuk halaman tersebut.';

      let message = `🧾  *T A G I H A N*\n(Page ${page}/${totalPages})\n\n`;

      options.forEach((option, index) => {
        message += `${startIndex + index + 1}. ${option}\n`;
      });

      if (uniqueOptions.length > endIndex) {
        message += `\nKirim *\`${command} ${args[0]} ${page + 1}\`* untuk melanjutkan ke page selanjutnya\n`;
      }

      client.reply(m.chat, message + '\nUntuk melihat daftar layanan produk kirim *\`tgh <no>\`*\n• Example : \`tgh 1\`' + '\n\n' + `${global.footer}`, m);
      } 
      if (args[0] === 'pbb') {
      const gameList = await fetchGameList();

      const page = args[1] ? parseInt(args[1]) : 1;
      if (isNaN(page)) return client.reply(m.chat, '🚩 *Page harus berupa nomor*', m);
      const pageSize = 2000;
      const startIndex = (page - 1) * pageSize;
      const endIndex = startIndex + pageSize;

      const uniqueOptions = Array.from(new Set(gameList.map(option => option.produk)));

      const options = uniqueOptions.slice(startIndex, endIndex);

      const totalOptions = uniqueOptions.length;
      const totalPages = Math.ceil(totalOptions / pageSize);

      if (options.length === 0) throw 'Tidak ada daftar produk untuk halaman tersebut.';

      let message = `🧾  *T A G I H A N - P B B*\n(Page ${page}/${totalPages})\n\n`;

      options.forEach((option, index) => {
        message += `${startIndex + index + 1}. ${option}\n`;
      });

      if (uniqueOptions.length > endIndex) {
        message += `\nKirim *\`${command} ${args[0]} ${page + 1}\`* untuk melanjutkan ke page selanjutnya\n`;
      }

      client.reply(m.chat, message + '\nUntuk melihat daftar layanan produk kirim *\`tpbb <no>\`*\n• Example : \`tpbb 1\`' + '\n\n' + `${global.footer}`, m);
      }
    } catch (e) {
      return client.reply(m.chat, `🚩 ${e}`, m);
    }
  },
  error: false,
  location: __filename,
};