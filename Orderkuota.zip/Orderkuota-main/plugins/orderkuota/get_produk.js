const fetch = require('node-fetch');

exports.run = {
   usage: ['get-produk'],
   use: 'code_produk',
   category: 'orderkuota',
   async: async (m, { client, text, Func }) => {
      try {
         if (!text) {
            return client.reply(m.chat, 'Silakan masukkan kode produk yang ingin Anda cari.', m);
         }

         const productCode = text.trim();
         const hargaID = process.env.ORDERKUOTA_HARGA_ID;
         const response = await fetch(`https://okeconnect.com/harga/json?id=${hargaID}`);
         const data = await response.json();

         if (!data || data.length === 0) {
            return client.reply(m.chat, 'Data produk tidak ditemukan.', m);
         }

         const product = data.find(prod => prod.kode === productCode);

         if (!product) {
            return client.reply(m.chat, 'Produk dengan kode tersebut tidak ditemukan.', m);
         }
         let laba = parseInt(process.env.ORDERKUOTA_LABA);
         let total = parseInt(product.harga) + laba;
         const info = `*🆔Kode Produk :* ${product.kode}
*📝Keterangan :* ${product.keterangan}
*🏷️Produk :* ${product.produk}
*🛍️Kategori :* ${product.kategori}
*💵Harga :* Rp ${Func.formatNumber(total)}
*🟢Status :* ${product.status === '0' ? 'Tidak Aktif' : 'Aktif'}

${global.footer}`;

         client.reply(m.chat, info, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, 'Terjadi kesalahan dalam mendapatkan detail produk.', m);
      }
   },
   error: false,
   location: __filename
};