const fs = require('fs');
const axios = require('axios'); 

exports.run = {
   usage: ['menu', 'allmenu'],
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      setting,
      users,
      plugins,
      env,
      Func
   }) => {
      try {
         client.menu = client.menu ? client.menu : {}
         const id = m.chat
         const local_size = fs.existsSync('./' + env.database + '.json') ? await Func.getSize(fs.statSync('./' + env.database + '.json').size) : ''
         const library = JSON.parse(require('fs').readFileSync('./package.json', 'utf-8'))
         let number = (m.sender).split('@')[0];
         const profileData = await getProfileData(number);
         if (!profileData) {
            return client.sendMessageModify(m.chat, `⚠️ *W A R N I N G*

*Ikuti Step By Step Berikut Proses Verifikasi :*

*– STEP 1 :*
Kirim pesan *signup* / *login* 

• \`Sign Up\` = _Membuat Akun_
• \`Login\` = _Masuk ke Akun yang sudah di buat sebelumnya_

*– STEP 2 :*
Lalu selanjutnya akan dimintai Email, Username & Pasword

"berikan sesuai dengan yang diminta"


~ Jika ada pertanyaan chat \`OWNER\``, m, {
                  largeThumb: true,
                  thumbnail: 'https://i.ibb.co/nfgVD9j/image.jpg',
                  url: setting.link
               })
         }
         if (!profileData.status) {
            return client.reply(m.chat, `🚩 Status Akun anda masih dalam proses, Silahkan kirimkan code verifikasi yang masuk di *Email* anda`, m);
         }
         let statusText = profileData.status ? '✅' : '❎';
         const message = `Hi @${m.sender.replace(/@.+/g, '')}🪸
I am an automated system (WhatsApp Bot) that can help to do something, search and get data / information only through WhatsApp.

○ *Login : ${statusText}*
○ *Username : ${profileData.username}*
○ *Saldo Deposit :* Rp. ${Func.formatNumber(profileData.saldo)}
○ *Total Pembelian :* ${Func.formatNumber(profileData.total_pembelian)} 🛒
○ *Total Pengeluaran :* Rp. ${Func.formatNumber(profileData.total_pengeluaran)}

If you find an error or want to upgrade premium plan contact the owner.`
         if (command === 'menu') {
            let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage && obj.run.category && obj.run.category.toLowerCase() === 'orderkuota')
            let cmd = Object.fromEntries(filter)
            let category = []
            for (let name in cmd) {
               let obj = cmd[name].run
               if (!cmd) continue
               if (!obj.category || setting.hidden.includes(obj.category)) continue
               if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)
               else {
                  category[obj.category] = []
                  category[obj.category].push(obj)
               }
            }
            const keys = Object.keys(category).sort()
            let print = message
            print += '\n' + String.fromCharCode(8206).repeat(4001)
            for (let k of keys) {
               print += '\n\n🛍️  *' + k.toUpperCase().split('').map(v => v).join(' ') + '*\n\n'
               let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category == k.toLowerCase())
               let usage = Object.keys(Object.fromEntries(cmd))
               if (usage.length == 0) return
               let commands = []
               cmd.map(([_, v]) => {
                  switch (v.run.usage.constructor.name) {
                     case 'Array':
                        v.run.usage.map(x => commands.push({
                           usage: x,
                           use: v.run.use ? Func.texted('bold', v.run.use) : ''
                        }))
                        break
                     case 'String':
                        commands.push({
                           usage: v.run.usage,
                           use: v.run.use ? Func.texted('bold', v.run.use) : ''
                        })
                  }
               })
               print += commands.sort((a, b) => a.usage.localeCompare(b.usage)).map(v => `	◦  ${isPrefix + v.usage} ${v.use}`).join('\n')
            }
            client.sendMessageModify(m.chat, print + '\n\n' + global.footer, m, {
               ads: false,
               largeThumb: true,
               thumbnail: setting.cover,
               url: setting.link
            })
         } else if (command === 'allmenu') {
            let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)
            let cmd = Object.fromEntries(filter)
            let category = []
            for (let name in cmd) {
               let obj = cmd[name].run
               if (!cmd) continue
               if (!obj.category || setting.hidden.includes(obj.category)) continue
               if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)
               else {
                  category[obj.category] = []
                  category[obj.category].push(obj)
               }
            }
            const keys = Object.keys(category).sort()
            let print = message
            print += '\n' + String.fromCharCode(8206).repeat(4001)
            for (let k of keys) {
               print += '\n\n –  *' + k.toUpperCase().split('').map(v => v).join(' ') + '*\n\n'
               let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category == k.toLowerCase())
               let usage = Object.keys(Object.fromEntries(cmd))
               if (usage.length == 0) return
               let commands = []
               cmd.map(([_, v]) => {
                  switch (v.run.usage.constructor.name) {
                     case 'Array':
                        v.run.usage.map(x => commands.push({
                           usage: x,
                           use: v.run.use ? Func.texted('bold', v.run.use) : ''
                        }))
                        break
                     case 'String':
                        commands.push({
                           usage: v.run.usage,
                           use: v.run.use ? Func.texted('bold', v.run.use) : ''
                        })
                  }
               })
               print += commands.sort((a, b) => a.usage.localeCompare(b.usage)).map((v, i) => {
                  if (i == 0) {
                     return `┌  ◦  ${isPrefix + v.usage} ${v.use}`
                  } else if (i == commands.sort((a, b) => a.usage.localeCompare(b.usage)).length - 1) {
                     return `└  ◦  ${isPrefix + v.usage} ${v.use}`
                  } else {
                     return `│  ◦  ${isPrefix + v.usage} ${v.use}`
                  }
               }).join('\n')
            }
            client.sendMessageModify(m.chat, print + '\n\n' + global.footer, m, {
               ads: false,
               largeThumb: true,
               thumbnail: setting.cover,
               url: setting.link
            })
         }
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}

async function getProfileData(number) {
   try {
const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Cari profile berdasarkan nomor
      let profileData = null;
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoNumber = key.split('°')[2]; // Ambil number dari key

            if (userInfoNumber === number) {
               const [email, username] = key.split('°');
               profileData = {
                  email: email,
                  username: username,
                  saldo: userInfo.saldo,
                  total_pembelian: userInfo.total_pembelian,
                  total_pengeluaran: userInfo.total_pengeluaran,
                  account_create: userInfo.account_create,
                  status: userInfo.status // Tambahkan status akun
               };
               break;
            }
         }
      }

      return profileData; // Kembalikan profile data
   } catch (error) {
      console.error('Failed to get profile data:', error.message);
      throw error;
   }
}

