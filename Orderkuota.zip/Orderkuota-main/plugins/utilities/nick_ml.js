const fetch = require('node-fetch');
const md5 = require('md5');
const FormData = require('form-data');

exports.run = {
   usage: ['nick-ml'],
   use: 'id|zone',
   category: 'nickname game', 
   async: async (m, { client, text, isPrefix, command }) => {
      try {
         const [userId, zoneId] = text.split`|`; 
         if (!userId || !zoneId) return client.reply(m.chat, `🚩 *Masukkan iduser dan zoneid*
         
• Contoh :
${isPrefix + command} id_user|zone_id
${isPrefix + command} 1160977561|13701`, m);
         const apiKey = process.env.VIPA_API_KEY;
         const apiId = process.env.VIPA_API_ID;

         const formData = new FormData();
         formData.append("key", apiKey);

         // Hitung nilai md5(API ID + API KEY)
         const md5Value = md5(apiId + apiKey);
         formData.append("sign", md5Value);

         formData.append("type", "get-nickname");
         formData.append("code", "mobile-legends");
         formData.append("target", userId);
         formData.append("additional_target", zoneId);

         // Lakukan request menggunakan fetch
         const response = await fetch("https://vip-reseller.co.id/api/game-feature", {
            method: "POST",
            body: formData
         });

         const responseData = await response.json();
         if (response.ok && responseData.result) {
            const nickname = responseData.data;
            const reply = `*Nickname Game*\n\nUser ID: ${userId}\nZone ID: ${zoneId}\nNickname: ${nickname}`;
            client.reply(m.chat, reply, m);
         } else {
            const errorMessage = responseData.message || 'Gagal mendapatkan nickname game';
            return client.reply(m.chat, `🚩 ${errorMessage}`, m);
         }
      } catch (e) {
         return client.reply(m.chat, `error`, m);
      }
   },
   error: false,
   location: __filename
};