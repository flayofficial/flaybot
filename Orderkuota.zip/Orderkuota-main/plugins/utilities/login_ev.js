const axios = require('axios');
const moment = require('moment-timezone');
const nodemailer = require('nodemailer');

exports.run = {
  async: async (m, { client, Func, users, command, isPrefix }) => {
    try {
      // Pastikan pesan bukan tipe 'protocolMessage'
      if (m.mtype === 'protocolMessage') {
        return
        }

      if (users.login_username) {
        if (typeof m.text !== 'string' || m.text.length < 5 && m.fromMe === false) {
          return client.reply(m.chat, '🚩 Username Minimal 5 Huruf', m);
        }

        let username = m.text.trim();
        let foundUser = await findUserByUsername(username);
        if (!foundUser) {
          users.login_username = false;
          return client.reply(m.chat, '🚩 Username tidak ditemukan / Username belum terdaftar', m);
        }

        users.login_username = false;
        users.login_password = true;
        users.username = username;
        client.reply(m.chat, '🚩 Silahkan kirimkan *Password* pada akun tersebut', m);
      } else if (users.login_password) {
        if (typeof m.text !== 'string' || m.text.length < 6 && m.fromMe === false) {
          return client.reply(m.chat, '🚩 Password Minimal 6 Character', m);
        }

        users.login_password = false;
        client.reply(m.chat, '*Checking Account . . .*', m);

        let number = (m.sender).split('@')[0];
        let foundUser = await findUserByUsername(users.username);
        if (foundUser && foundUser.password === m.text) {
          await updateStatusByUsername(users.username, true);
          await sendVerificationCode(foundUser.email, Func, client, m);
          users.login = true;
        } else {
          return client.reply(m.chat, '❌ Password Akun Salah', m);
        }
      }
    } catch (e) {
      console.log(e);
      client.reply(m.chat, Func.jsonFormat(e), m);
    }
  },
  error: false,
  private: true,
  location: __filename
}

// Fungsi untuk mencari user berdasarkan username
async function findUserByUsername(username) {
  try {
    const gh = process.env.USERNAME_GH;
    const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
    const token = process.env.TOKEN_GH;

    const response = await axios.get(apiUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const content = response.data.content;
    const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
    const jsonData = JSON.parse(decodedContent);

    for (const key in jsonData) {
      if (jsonData.hasOwnProperty(key)) {
        const userInfo = jsonData[key];
        const userInfoUsername = key.split('°')[1];

        if (userInfoUsername === username) {
          const [email, username] = key.split('°');
          return {
            email: email,
            username: username,
            password: userInfo.password
          };
        }
      }
    }

    return null;
  } catch (error) {
    console.error('Failed to find user by username:', error.message);
    throw error;
  }
}

// Fungsi untuk mengupdate status pengguna berdasarkan username
async function updateStatusByUsername(username, status) {
  try {
    const gh = process.env.USERNAME_GH;
    const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
    const token = process.env.TOKEN_GH;

    const response = await axios.get(apiUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const content = response.data.content;
    const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
    const jsonData = JSON.parse(decodedContent);

    const key = Object.keys(jsonData).find(key => key.toLowerCase().split('°')[1] === username.toLowerCase());
    if (key) {
      jsonData[key].status = status;

      const updatedContent = JSON.stringify(jsonData, null, 2);
      const encodedContent = Buffer.from(updatedContent).toString('base64');

      await axios.put(apiUrl, {
        message: `Update status for ${username}`,
        content: encodedContent,
        sha: response.data.sha,
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    }
  } catch (error) {
    console.error('Failed to update status by username:', error.message);
    throw error;
  }
}

// Fungsi untuk mengirimkan kode verifikasi ke email pengguna
async function sendVerificationCode(email, Func, client, m) {
  try {
    let transport = nodemailer.createTransport({
      service: process.env.USER_EMAIL_PROVIDER,
      auth: {
        user: process.env.USER_EMAIL,
        pass: process.env.USER_APP_PASSWORD
      }
    });

    let code = `${Func.randomInt(1000, 9999)}-${Func.randomInt(100, 999)}-${Func.randomInt(1000, 9000)}`;
    let users = global.db.users.find(v => v.jid == m.sender);
    users.code = code;

    let mailOptions = {
      from: {
        name: process.env.USER_NAME,
        address: process.env.USER_EMAIL
      },
      to: email,
      subject: 'Kode Verifikasi untuk Login ORDERKUOTA',
      html: `<div style="padding:20px;border:1px dashed #222;font-size:15px"><tt>Hi <b>${m.pushName} 🛍️</b><br><br><img src="https://iili.io/JCjUqdv.jpg" alt="Thumbnail"><br><br>Konfirmasikan email Anda untuk membuat Akun ${process.env.USER_NAME}. Kirim kode ini ke bot.<br><center><h1>${code}</h1></center>Atau salin dan tempel URL di bawah ini ke browser Anda : <a href="https://wa.me/${client.decodeJid(client.user.id).split('@')[0]}?text=${code}">https://wa.me/${client.decodeJid(client.user.id).split('@')[0]}?text=${code}</a><br><br><hr style="border:0px; border-top:1px dashed #222"><br>With, <b>© YanaMiku</b></tt></div>`
    };

    transport.sendMail(mailOptions, function(err, data) {
      if (err) {
        console.error('Failed to send verification code email:', err);
        return client.reply(m.chat, Func.texted('bold', '❌ Gagal mengirim email verifikasi'), m);
      } else {
        console.log('Verification code email sent successfully');
        return client.reply(m.chat, Func.texted('bold', '✅ Kode verifikasi telah dikirimkan ke email Anda. Kirim code verifikasi untuk Login ke Akun'), m);
      }
    });
  } catch (error) {
    console.error('Failed to send verification code email:', error.message);
    throw error;
  }
}
